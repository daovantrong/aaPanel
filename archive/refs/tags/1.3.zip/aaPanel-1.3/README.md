### aaPanel & 宝塔面板 小助手

## 使用方法
#### 国外VPS
```
wget -O aapanel.sh https://raw.githubusercontent.com/daovantrong/aaPanel/main/script/aapanel.sh && chmod +x aapanel.sh && clear && ./aapanel.sh
```

#### 国内VPS
```
wget -O aapanel.sh https://ghproxy.com/https://raw.githubusercontent.com/daovantrong/aaPanel/main/script/aapanel.sh && chmod +x aapanel.sh && clear && ./aapanel.sh
```

#### 功能介绍
- 降级`aapanel面板`到最后一个无广告版本
- 汉化`aapanel面板`
- 降级`宝塔面板`到`7.7.0`以及去除绑定
- 开心`aapane`&`宝塔面板`

![bash](https://ghproxy.com/https://raw.githubusercontent.com/daovantrong/aaPanel/main/resource/bash.png)

## 更新日志

### 2022年5月30日
- 修改脚本路径

### 2022年5月17日
- 将汉化文件更换为Gitee上找到的文件（想对我制作的更全一些）
- 新增宝塔面板降级

### 2022年5月16日
- 制作汉化文件

### 2022年5月15日
- 完成脚本