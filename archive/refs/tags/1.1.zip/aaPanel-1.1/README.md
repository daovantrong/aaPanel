### aaPanel 面板降级到最后一个无广告版本

## 使用方法
#### 国外VPS
```
wget -O aapanel.sh https://raw.githubusercontent.com/daovantrong/aaPanel/main/aapanel.sh && chmod +x aapanel.sh && clear && ./aapanel.sh
```

#### 国内VPS
```
wget -O aapanel.sh https://ghproxy.com/https://raw.githubusercontent.com/daovantrong/aaPanel/main/aapanel.sh && chmod +x aapanel.sh && clear && ./aapanel.sh
```
